define([
  './panellinks/module',
  './dashlinks/module',
  './annotations/annotationsSrv',
  './templating/templateSrv',
  './dashboard/all',
  './panel/all',
  './profile/profileCtrl',
  './profile/changePasswordCtrl',
  './profile/selectOrgCtrl',
  './admin/all',
], function () {});
