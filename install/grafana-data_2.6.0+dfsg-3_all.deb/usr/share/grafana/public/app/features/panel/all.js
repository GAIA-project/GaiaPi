define([
  './panel_menu',
  './panel_directive',
  './panel_srv',
  './panel_helper',
  './solo_panel_ctrl',
], function () {});
