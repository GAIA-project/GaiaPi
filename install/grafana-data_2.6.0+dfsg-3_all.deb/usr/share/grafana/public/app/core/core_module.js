///<reference path="../headers/common.d.ts" />
define(["require", "exports", 'angular'], function (require, exports, angular) {
    return angular.module('grafana.core', ['ngRoute']);
});
